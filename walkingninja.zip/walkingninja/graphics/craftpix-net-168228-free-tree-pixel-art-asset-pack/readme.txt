Font that was used for the background of the preview:
https://www.dafont.com/digital-disco.font